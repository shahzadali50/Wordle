<div>
    <div class="flex gap-10 justify-stretch  w-full flex-wrap" style="margin-top: 115px;">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal59bf8429bf11be0d896ef8c4fe241b6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59bf8429bf11be0d896ef8c4fe241b6b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.game-card','data' => ['title' => ''.e($game['title']).'','image' => ''.e($game['image'] ?? 'default-image-url.png').'','route' => ''.e(route('games.show', ['slug' => $slug])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('game-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($game['title']).'','image' => ''.e($game['image'] ?? 'default-image-url.png').'','route' => ''.e(route('games.show', ['slug' => $slug])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59bf8429bf11be0d896ef8c4fe241b6b)): ?>
<?php $attributes = $__attributesOriginal59bf8429bf11be0d896ef8c4fe241b6b; ?>
<?php unset($__attributesOriginal59bf8429bf11be0d896ef8c4fe241b6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59bf8429bf11be0d896ef8c4fe241b6b)): ?>
<?php $component = $__componentOriginal59bf8429bf11be0d896ef8c4fe241b6b; ?>
<?php unset($__componentOriginal59bf8429bf11be0d896ef8c4fe241b6b); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\wordle-dev\resources\views/livewire/game-list.blade.php ENDPATH**/ ?>