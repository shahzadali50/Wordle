<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'image', 'route']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'image', 'route']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="max-w-82 bg-white rounded-lg max-h-62 game-card">
    <a href="<?php echo e($route); ?>" class=" cursor-pointer border border-gray-300 rounded-lg block">
        <img  class=" game-card-img img-fluid  max-w-[251px] object-cover object-center min-w-[250px] max-h-[151px] min-h-[150px] border-2 border-black rounded-lg"
            src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>">
        <p class="text-black text-xl font-semibold text-center mt-3 mb-3"><?php echo e($title); ?></p>
    </a>
</div>
<?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\wordle-dev\resources\views/components/game-card.blade.php ENDPATH**/ ?>