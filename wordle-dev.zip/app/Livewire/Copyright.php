<?php

namespace App\Livewire;

use Livewire\Component;

class Copyright extends Component
{
    public function render()
    {
        return view('livewire.copyright');
    }
}
